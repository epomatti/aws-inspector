func main() {
	println("Lambda!")
}
